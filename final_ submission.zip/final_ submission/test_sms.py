from glof_alert_system import GLOFAlertSystem, GLOFRiskLevel

def test_sms():
    # Initialize the alert system
    glof_system = GLOFAlertSystem(
        fast2sms_api_key="paste your api key here"
    )
    
    # Use a short message for quick SMS
    short_message = "GLOF TEST ALERT: Test Lake at HIGH risk."
    
    # Directly call the SMS provider for a focused test
    response = glof_system.sms_provider.send_glof_sms([
        "mobile no 1",  # Example: Defence Authority
        "mobile no 2",  # Example: Emergency Team
        "mobile no 3"   # Example: Local store
    ], short_message)
    
    print("SMS Provider Response:", response)
    print(f"SMS Test Result: {'Success' if response.get('success') else 'Failed'}")

if __name__ == "__main__":
    test_sms() 