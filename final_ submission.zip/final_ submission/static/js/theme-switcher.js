// Theme switcher
function setTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
}

function toggleTheme() {
    const currentTheme = localStorage.getItem('theme') || 'light';
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    updateThemeIcon(newTheme);
}

function updateThemeIcon(theme) {
    const themeIcon = document.getElementById('theme-icon');
    if (themeIcon) {
        themeIcon.innerHTML = theme === 'light' ? '🌙' : '☀️';
    }
}

// Language switcher
const translations = {
    en: {
        'dashboard': 'Dashboard',
        'alerts': 'Alerts',
        'settings': 'Settings',
        'theme': 'Theme',
        'language': 'Language',
        'search': 'Search',
        'notifications': 'Notifications',
        'profile': 'Profile',
        'logout': 'Logout',
        'title': 'Glacier Lake Monitoring System',
        'subtitle': 'Real-time monitoring and alerts for glacial lake outburst floods'
    },
    hi: {
        'dashboard': 'डैशबोर्ड',
        'alerts': 'अलर्ट',
        'settings': 'सेटिंग्स',
        'theme': 'थीम',
        'language': 'भाषा',
        'search': 'खोज',
        'notifications': 'सूचनाएं',
        'profile': 'प्रोफ़ाइल',
        'logout': 'लॉग आउट',
        'title': 'ग्लेशियर लेक मॉनिटरिंग सिस्टम',
        'subtitle': 'ग्लेशियर झील विस्फोट बाढ़ के लिए रीयल-टाइम मॉनिटरिंग और अलर्ट'
    },
    gu: {
        'dashboard': 'ડેશબોર્ડ',
        'alerts': 'અલર્ટ',
        'settings': 'સેટિંગ્સ',
        'theme': 'થીમ',
        'language': 'ભાષા',
        'search': 'શોધ',
        'notifications': 'સૂચનાઓ',
        'profile': 'પ્રોફાઇલ',
        'logout': 'લોગઆઉટ',
        'title': 'ગ્લેશિયર લેક મોનિટરિંગ સિસ્ટમ',
        'subtitle': 'ગ્લેશિયર લેક આઉટબર્સ્ટ ફ્લડ્સ માટે રીયલ-ટાઇમ મોનિટરિંગ અને અલર્ટ'
    },
    mr: {
        'dashboard': 'डॅशबोर्ड',
        'alerts': 'अलर्ट',
        'settings': 'सेटिंग्स',
        'theme': 'थीम',
        'language': 'भाषा',
        'search': 'शोध',
        'notifications': 'सूचना',
        'profile': 'प्रोफाइल',
        'logout': 'लॉगआउट',
        'title': 'ग्लेशियर लेक मॉनिटरिंग सिस्टम',
        'subtitle': 'ग्लेशियर लेक आउटबर्स्ट फ्लड्ससाठी रीयल-टाइम मॉनिटरिंग आणि अलर्ट'
    }
};

function setLanguage(lang) {
    document.documentElement.setAttribute('data-lang', lang);
    localStorage.setItem('language', lang);
    updateContent(lang);
}

function updateContent(lang) {
    const elements = document.querySelectorAll('[data-translate]');
    elements.forEach(element => {
        const key = element.getAttribute('data-translate');
        if (translations[lang] && translations[lang][key]) {
            element.textContent = translations[lang][key];
        }
    });
}

// Initialize theme and language
document.addEventListener('DOMContentLoaded', () => {
    const savedTheme = localStorage.getItem('theme') || 'light';
    const savedLang = localStorage.getItem('language') || 'en';
    
    setTheme(savedTheme);
    setLanguage(savedLang);
    updateThemeIcon(savedTheme);
}); 